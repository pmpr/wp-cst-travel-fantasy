<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4edca9e9             |
    |_______________________________________|
*/
 use Pmpr\Custom\TravelFantasy\TravelFantasy; TravelFantasy::symcgieuakksimmu();
