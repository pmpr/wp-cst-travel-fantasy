<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587d521c82             |
    |_______________________________________|
*/
 use Pmpr\Custom\TravelFantasy\TravelFantasy; TravelFantasy::symcgieuakksimmu();
