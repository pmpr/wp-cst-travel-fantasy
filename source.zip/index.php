<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1170f364b             |
    |_______________________________________|
*/
 use Pmpr\Custom\TravelFantasy\TravelFantasy; TravelFantasy::symcgieuakksimmu();
