<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4edca9e9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\CPT\CPT; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\124\162\x61\166\145\x6c\x20\x46\x61\x6e\x74\x61\x73\171\x20\103\165\x73\164\x6f\155", PR__CST__TRAVEL_FANTASY); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); } }
