<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a87a19821             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Custom\TravelFantasy\CPT\CPT; use Pmpr\Custom\TravelFantasy\CTX\CTX; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x54\x72\x61\x76\x65\x6c\x20\106\x61\x6e\x74\x61\x73\171\40\x43\x75\163\164\x6f\x6d", PR__CST__TRAVEL_FANTASY); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); CTX::symcgieuakksimmu(); } }
