<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1f5a0f069             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Custom\TravelFantasy\CPT\CPT; use Pmpr\Custom\TravelFantasy\CTX\CTX; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\124\x72\x61\166\145\154\x20\106\141\156\x74\x61\x73\171\40\x43\165\163\164\x6f\x6d", PR__CST__TRAVEL_FANTASY); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); CTX::symcgieuakksimmu(); } }
