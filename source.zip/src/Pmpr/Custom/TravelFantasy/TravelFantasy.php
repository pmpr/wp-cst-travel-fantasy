<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707e785873             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Custom\TravelFantasy\CPT\CPT; use Pmpr\Custom\TravelFantasy\CTX\CTX; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x54\162\x61\166\x65\154\x20\x46\x61\156\x74\141\x73\x79\x20\103\x75\x73\x74\x6f\155", PR__CST__TRAVEL_FANTASY); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); CTX::symcgieuakksimmu(); } }
