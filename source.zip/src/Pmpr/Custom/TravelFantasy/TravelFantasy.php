<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b43fd98             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Custom\TravelFantasy\CPT\CPT; use Pmpr\Custom\TravelFantasy\CTX\CTX; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\124\162\x61\x76\x65\x6c\x20\106\x61\x6e\164\x61\x73\x79\40\103\165\163\164\x6f\155", PR__CST__TRAVEL_FANTASY); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); CTX::symcgieuakksimmu(); } }
