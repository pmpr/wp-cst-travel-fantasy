<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8d813bb2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\CPT\CPT; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [Constants::qescuiwgsyuikume => static function () { return __("\x54\x72\141\x76\x65\154\x20\106\x61\156\164\141\163\171\40\x43\165\x73\164\x6f\155", PR__CST__TRAVEL_FANTASY); }, Constants::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); } }
