<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587d521c82             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Custom\TravelFantasy\CPT\CPT; use Pmpr\Custom\TravelFantasy\CTX\CTX; class TravelFantasy extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\124\162\x61\x76\145\154\x20\x46\x61\156\164\x61\x73\x79\40\103\165\163\x74\x6f\x6d", PR__CST__TRAVEL_FANTASY); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { CPT::symcgieuakksimmu(); CTX::symcgieuakksimmu(); } }
