<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1170f364b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy; use Pmpr\Common\Foundation\Container\Container as BaseClass; abstract class Container extends BaseClass { }
