<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707e785873             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\164", [$this, "\143\x61\x6f\145\151\x75\x71\x61\151\x71\171\x67\x6d\141\161\147"])->qcsmikeggeemccuu("\160\162\x65\x5f\147\145\x74\x5f\x70\157\163\164", [$this, "\x61\x69\x75\x6f\155\x63\x6d\x6d\x79\x67\x6f\x77\x6f\x73\x75\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query)) { goto qiaqsassksqiuyae; } if (!(($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query())) { goto cecuyayqoioasumi; } $gqgemcmoicmgaqie->set(self::uouymeyqasaeckso, [self::mswoacegomcucaik, self::imywcsggckkcywgk]); cecuyayqoioasumi: qiaqsassksqiuyae: } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(self::ocsomysosuqaimuc, self::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(self::qgciomgukmcwscqw, self::imywcsggckkcywgk); } }
