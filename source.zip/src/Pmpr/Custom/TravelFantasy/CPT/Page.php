<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4edca9e9             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\x63\x61\157\145\151\x75\161\141\151\161\x79\147\x6d\141\161\x67"])->qcsmikeggeemccuu("\x70\x72\x65\x5f\x67\145\164\x5f\160\157\x73\164", [$this, "\x61\x69\165\x6f\155\143\155\155\x79\147\157\167\157\163\x75\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query) { if (($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query()) { $gqgemcmoicmgaqie->set(Constants::uouymeyqasaeckso, [Constants::mswoacegomcucaik, Constants::imywcsggckkcywgk]); } } } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::ocsomysosuqaimuc, Constants::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::qgciomgukmcwscqw, Constants::imywcsggckkcywgk); } }
