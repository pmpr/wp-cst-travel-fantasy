<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400b43fd98             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\151\x74", [$this, "\143\141\157\145\x69\x75\x71\141\x69\x71\x79\147\155\x61\161\147"])->qcsmikeggeemccuu("\x70\x72\x65\137\x67\x65\x74\137\160\157\163\164", [$this, "\141\x69\x75\x6f\x6d\143\x6d\155\171\147\157\x77\157\163\x75\x77"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query)) { goto qiaqsassksqiuyae; } if (!(($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query())) { goto cecuyayqoioasumi; } $gqgemcmoicmgaqie->set(self::uouymeyqasaeckso, [self::mswoacegomcucaik, self::imywcsggckkcywgk]); cecuyayqoioasumi: qiaqsassksqiuyae: } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(self::ocsomysosuqaimuc, self::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(self::qgciomgukmcwscqw, self::imywcsggckkcywgk); } }
