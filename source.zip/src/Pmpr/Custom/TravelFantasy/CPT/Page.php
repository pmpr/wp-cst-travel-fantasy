<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1f5a0f069             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\164", [$this, "\143\x61\157\145\151\x75\x71\x61\x69\161\171\x67\x6d\141\x71\x67"])->qcsmikeggeemccuu("\160\162\145\x5f\147\145\x74\x5f\x70\x6f\x73\x74", [$this, "\x61\151\165\157\x6d\143\x6d\155\171\x67\157\167\x6f\163\165\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query)) { goto qiaqsassksqiuyae; } if (!(($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query())) { goto cecuyayqoioasumi; } $gqgemcmoicmgaqie->set(self::uouymeyqasaeckso, [self::mswoacegomcucaik, self::imywcsggckkcywgk]); cecuyayqoioasumi: qiaqsassksqiuyae: } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(self::ocsomysosuqaimuc, self::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(self::qgciomgukmcwscqw, self::imywcsggckkcywgk); } }
