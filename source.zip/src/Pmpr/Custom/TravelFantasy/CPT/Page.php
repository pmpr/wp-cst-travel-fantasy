<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4aba7eba8             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\151\x74", [$this, "\x63\141\157\x65\151\x75\x71\x61\x69\x71\171\147\x6d\x61\161\147"])->qcsmikeggeemccuu("\160\162\x65\x5f\x67\x65\164\x5f\160\x6f\163\x74", [$this, "\x61\151\165\157\x6d\x63\x6d\155\171\147\x6f\x77\157\163\165\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query) { if (($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query()) { $gqgemcmoicmgaqie->set(Constants::uouymeyqasaeckso, [Constants::mswoacegomcucaik, Constants::imywcsggckkcywgk]); } } } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::ocsomysosuqaimuc, Constants::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(Constants::qgciomgukmcwscqw, Constants::imywcsggckkcywgk); } }
