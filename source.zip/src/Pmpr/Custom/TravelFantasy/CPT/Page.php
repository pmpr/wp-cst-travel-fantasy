<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587d521c82             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\164", [$this, "\x63\141\x6f\x65\151\165\x71\x61\x69\x71\x79\x67\155\141\161\147"])->qcsmikeggeemccuu("\160\x72\145\137\x67\x65\x74\137\x70\157\163\x74", [$this, "\x61\x69\165\x6f\155\x63\155\x6d\171\x67\x6f\167\157\x73\x75\x77"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query)) { goto qiaqsassksqiuyae; } if (!(($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query())) { goto cecuyayqoioasumi; } $gqgemcmoicmgaqie->set(self::uouymeyqasaeckso, [self::mswoacegomcucaik, self::imywcsggckkcywgk]); cecuyayqoioasumi: qiaqsassksqiuyae: } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(self::ocsomysosuqaimuc, self::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(self::qgciomgukmcwscqw, self::imywcsggckkcywgk); } }
