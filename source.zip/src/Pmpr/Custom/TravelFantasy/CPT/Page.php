<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a87a19821             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; use WP_Query; class Page extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\x74", [$this, "\143\x61\157\145\151\165\x71\x61\x69\x71\x79\x67\155\x61\x71\x67"])->qcsmikeggeemccuu("\x70\162\x65\137\147\x65\x74\137\160\157\x73\x74", [$this, "\x61\x69\165\157\155\143\155\x6d\171\147\157\x77\x6f\x73\x75\167"]); } public function aiuomcmmygowosuw($gqgemcmoicmgaqie) { if (!(!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg() && $gqgemcmoicmgaqie instanceof WP_Query)) { goto qiaqsassksqiuyae; } if (!(($gqgemcmoicmgaqie->is_category || $gqgemcmoicmgaqie->is_tag) && $gqgemcmoicmgaqie->is_main_query())) { goto cecuyayqoioasumi; } $gqgemcmoicmgaqie->set(self::uouymeyqasaeckso, [self::mswoacegomcucaik, self::imywcsggckkcywgk]); cecuyayqoioasumi: qiaqsassksqiuyae: } public function caoeiuqaiqygmaqg() { $cqcqsgykasiqwowi = $this->uwkmaywceaaaigwo()->yyoeeseewqmmyaee(); $cqcqsgykasiqwowi->ycewygugskisecuo(self::ocsomysosuqaimuc, self::imywcsggckkcywgk); $cqcqsgykasiqwowi->ycewygugskisecuo(self::qgciomgukmcwscqw, self::imywcsggckkcywgk); } }
