<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             694c4d605d1f4             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); } }
