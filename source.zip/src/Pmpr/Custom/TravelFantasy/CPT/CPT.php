<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8d813bb2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CPT; use Pmpr\Custom\TravelFantasy\Container; class CPT extends Container { public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); } }
