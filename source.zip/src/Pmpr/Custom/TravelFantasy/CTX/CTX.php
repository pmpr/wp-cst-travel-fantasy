<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e1f5a0f069             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CTX; use Pmpr\Custom\TravelFantasy\Container; class CTX extends Container { public function mameiwsayuyquoeq() { } }
