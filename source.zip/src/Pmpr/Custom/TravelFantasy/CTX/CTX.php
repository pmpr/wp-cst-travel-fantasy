<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660587d521c82             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CTX; use Pmpr\Custom\TravelFantasy\Container; class CTX extends Container { public function mameiwsayuyquoeq() { } }
