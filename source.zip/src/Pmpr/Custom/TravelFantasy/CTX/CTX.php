<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a87a19821             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\TravelFantasy\CTX; use Pmpr\Custom\TravelFantasy\Container; class CTX extends Container { public function mameiwsayuyquoeq() { } }
